
package yapiciMethodlar;


public class Yetenek {
    
    int i = 5;
    
    public Yetenek() {
        System.out.println("Yetenek call");
    }
    
    
    public Yetenek(int i) {
        this.i = i;
    }
    
    
    public void call(int num) {
        int end = num * i;
        System.out.println("end : " + end);
    }
    
    
    public void call(int num, String name) {
        int end = num * i;
        System.out.println("end : " + end);
    }
    
    
}
