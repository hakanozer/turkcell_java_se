
package yapiciMethodlar;


public class ConstMainApp {
    
    public static void main(String[] args) {
        
        Yetenek yt = new Yetenek(8);
        yt.call(5);
        
        
        
    }
    
    
}
