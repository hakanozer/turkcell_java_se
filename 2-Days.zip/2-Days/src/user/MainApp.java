
package user;

import pkg2.days.Util;



public class MainApp {
    
    public static void main(String[] args) {
        
        Util ut = new Util();
        
        
    }
    
}
