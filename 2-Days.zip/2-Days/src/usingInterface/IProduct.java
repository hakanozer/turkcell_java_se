
package usingInterface;


public interface IProduct {
    
    void productName();
    int minus(int a, int b);
    int fncSum(int a, int b);
    
}
