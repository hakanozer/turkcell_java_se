
package usingInterface;


public class Util implements IUser, IProduct {

    @Override
    public int fncSum(int a, int b) {
        return a + b;
    }

    @Override
    public void write() {
        defaultMethod();
        System.out.println("Write Call");
    }

    @Override
    public void productName() {
        System.out.println("Product Name");
    }

    @Override
    public int minus(int a, int b) {
        return a - b;
    }

    @Override
    public String profile(int id) {
        return "";
    }

    @Override
    public boolean fncUserSetName(String name, int uid) {
        return true;
    }

    
    
}
