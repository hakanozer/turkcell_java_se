
package usingInterface;

public interface IUser extends Settings {
    
    int fncSum(int a, int b);
    void write();
    String profile(int id);
    
    
    // normal method
    default public void defaultMethod() {
        System.out.println("defaultMethod call");
    }
    
    
}
