
package pkg2.days;


public class Days {

    public static void main(String[] args) {
        
        Util nesne = new Util();
        Util nesne1 = new Util();
        nesne1.a = 20;
        
        // noParameter call
        nesne.noParameter();
        
        // parameter call
        nesne1.parameter(50, 90);
        nesne.parameter(50, 90);
        nesne.a = 10;
        nesne.parameter(5, 7);
        nesne.parameter(44, 77);
        
        // return call
        int min = nesne.fncReturn(98, 34);
        if (min > 55) {
            System.out.println("Min > 55 " + min);
        }
        
        
        // ... parameter
        String dt = nesne.fncString("Ali", "Veli", "Hasan", "Mehmet");
        System.out.println(dt);
        

        Util.Product pro = new Util().new Product();
        pro.read();
        
        
    }
    
}
