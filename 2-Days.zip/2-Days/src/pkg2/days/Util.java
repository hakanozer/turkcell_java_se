
package pkg2.days;


public class Util {
    
    public int a = 0;
    String name = "Ali";
    private String surname = "Bilmem";
    
    // no return and no parameter
    public void noParameter() {
        Settings st = new Settings();
        st.write();
        System.out.println("noParameter call " + surname);
    }
    
    
    // no return
    public void parameter( int num1, int num2 ) {
        int sum = num1 + num2  + a;
        System.out.println("sum : " + sum);
    }
    
    
    // return
    public int fncReturn( int num1, int num2 ) {
        int minus = num1 - num2;
        return minus;
    }
    
    // ... return
    public String fncString( String... data ) {
        String dt = "";
        for (String item : data) {
            dt += item + " ";
        }
        return dt;
    }
    
    
    private class Settings {
        
        public void write() {
            System.out.println("write call");
        }
        
    }
    
    
    class Product {
        
        public void read() {
            System.out.println("read call");
        }
        
    }
    
    
    
}
