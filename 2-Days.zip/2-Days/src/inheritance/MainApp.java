
package inheritance;


public class MainApp {
    
    public static void main(String[] args) {
        
        Base nsa = new A();
        Base nsb = new B();
        Base nsc = new C();
        
        call(nsa);
        call(nsb);
        call(nsc);
        

        //CustomButton customButton = new CustomButton("Sum");
    }
    
    
    public static void call( Base base) {
        /*
        if (base instanceof A) {
            A nsa = (A) base;
            nsa.read();
        }*/
        base.write();
    }
    
    
    
}
