
package inheritance;


public class Base {

    public Base() {
        System.out.println("Base Call");
    }

    
    public void write() {
        System.out.println("write Call");
    }
    
    public void sum(int a, int b) {
        int sm = a + b;
        System.out.println("Sm : " + sm);
    }
    
    
}
