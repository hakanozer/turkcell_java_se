
package inheritance;


public class A extends Base {

    @Override
    public void write() {
        System.out.println("A write call");
        read();
    }
    
    public void read() {
        System.out.println("Read Call");
    }
    
}
