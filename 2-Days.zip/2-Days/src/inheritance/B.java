/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author hakan
 */
public class B extends Base {

    @Override
    public void write() {
        System.out.println("B write call");
    }
    
    
    
}

