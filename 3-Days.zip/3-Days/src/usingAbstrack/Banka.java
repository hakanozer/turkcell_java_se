
package usingAbstrack;

public abstract class Banka {
    
    int tcNo = 0;
    public abstract void userTCNo();
    
    public void paraCek(int miktar) {
        System.out.println(tcNo + " TC Nolu Müşteri "+miktar+" TL Para Çekti ");
    }
    
}
