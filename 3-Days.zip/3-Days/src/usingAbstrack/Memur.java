
package usingAbstrack;


public class Memur {
    

    public static void main(String[] args) {
        
        Musteri musteri = new Musteri();
        musteri.userTCNo();
        musteri.paraCek(1000);
        
    }
    
}
