
package usingAbstrack;


public class Musteri extends Banka {

    @Override
    public void userTCNo() {
        tcNo = 23456789;
    }
    
}
