/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3.days;

import usingInterface.IOrder;
import usingInterface.User;

/**
 *
 * @author hakan
 */
public class Days {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println(User.city);
        User.city = "İzmir";
        System.out.println(User.city);
        
        User us = new User();
        System.out.println(us.city);
        String[] arr = us.orderList(0);
        for (String item : arr) {
            System.out.println("item : " + item);
        }
        
        
        IOrder ns1 = new IOrder() {
            @Override
            public String[] orderList(int uid) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        
    }
    
}
