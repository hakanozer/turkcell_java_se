
package usingHashMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


public class MainMap {
    
    public static void main(String[] args) {
        
        
        HashMap<String, String> map = new HashMap<>();
        
        // item add
        map.put("name", "Ayşe");
        map.put("name", "Zehra");
        map.put("surname", "Bilmem");
        map.put("age", "40");
        
        // size
        int size = map.size();
        System.out.println("Size : " + size);
        
        // single item
        String itm = map.get("surname");
        System.out.println(itm);
        
        
        System.out.println(map.get("name").hashCode());
        System.out.println(map.get("surname").hashCode());
        System.out.println(map.get("age").hashCode());
        
        // all item read
        System.out.println(map);
        
        
        // Set -> keys
        Set<String> keys = map.keySet();
        for (String key : keys) {
            String val = map.get(key);
            System.out.println("key : " + key + " val : " + val);
        }
        
        
        // delete item
        map.remove("age");
        
        
        // java 8 lambda foreach
        map.forEach( (key, val) -> { 
            System.out.println("forEach key : " + key + " val : " + val);
        });
        
        
        
        // LinkedHashMap
        Map<String, String> hm = new LinkedHashMap<>();
        hm.put("name", "Ayşe");
        hm.put("name", "Zehra");
        hm.put("surname", "Bilmem");
        hm.put("age", "40");
        
        System.out.println(hm);
        
    }
    
    
}
