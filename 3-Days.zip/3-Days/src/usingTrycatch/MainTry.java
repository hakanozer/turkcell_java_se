
package usingTrycatch;

import java.util.Random;


public class MainTry {
    
    public static void main(String[] args) {
        
        System.out.println("Program Başladı");
        
        try {
            Random rd = null;
            System.out.println(rd.nextInt());
        } catch (Exception e) {
            System.err.println("Error : " + e);
        }
        
        System.out.println("Program Bitti");
        
    }
    
}
