
package usingInterface;


public class User implements IUser, IOrder {
    
    static public String city = "İstanbul";
    final public String area = "Marmara";

    @Override
    public String userName(int uid) {
        
        if (uid == 10){
            return "Ali Bilmem";
        }
        return "";
    }

    @Override
    public String userPhoto(int uid) {
        if (uid == 10) {
            return "photo1.jpg";
        }
        return "";
    }

    @Override
    public String[] orderList(int uid) {
        String[] list = { "Buzdolabı", "Televizyon", "iPhone X" };
        return list;
    }
    
}
