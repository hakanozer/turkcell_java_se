
package usingInterface;

public interface IUser {
    
    String userName(int uid);
    String userPhoto(int uid);
    
    
}
