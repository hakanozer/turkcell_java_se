
package usingCollections;

import java.util.ArrayList;


public class UArrayList {
    
    public static void main(String[] args) {
        
        ArrayList<String> ls = new ArrayList<>();
        String[] arr = { "İstanbul", "İzmir" };
        
        
        // item add
        ls.add("İstanbul");
        ls.add("İzmir");
        ls.add("Ankara");
        ls.add("Bursa");
        
        // size
        int size = ls.size();
        System.out.println("size : " + size);
        
        // all items
        System.out.println(arr);
        System.out.println(ls);
        
        
        // single item
        String item = ls.get(3);
        System.out.println(item);
        
        // remove item
        ls.remove(0);
        
        // all Remove item
        ls.clear();
        
        // all items foreach
        for ( String itm : ls ) {
            System.out.println("item : " + itm);
        }
        
        
    }
    
}
