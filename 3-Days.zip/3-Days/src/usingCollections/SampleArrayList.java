
package usingCollections;

import java.util.ArrayList;
import java.util.Scanner;


public class SampleArrayList {
    
    
    public static void main(String[] args) {
        
        ArrayList<User> ls = new ArrayList<>();
        Scanner read = new Scanner(System.in);
        Scanner readInt = new Scanner(System.in);
        
        pullData(read, readInt, ls);
        resultData(ls);
        
    }
    
   
    public static void pullData(Scanner read, Scanner readInt, ArrayList<User> ls) {
        int i = 0;
        while(true){
            i++;
            User us = new User();
            
            us.setUid(i);
            
            System.out.println("Adı Soyadı");
            us.setNameSurname(read.nextLine());
            
            System.out.println("Mail Adresi");
            us.setMail(read.nextLine());
            
            System.out.println("Yaşı");
            us.setAge(readInt.nextInt());
            
            ls.add(us);
            
            // stop
            System.out.println("Durdur 0, Devam 1");
            int statu = readInt.nextInt();
            if(statu == 0) {
                break;
            }
        }
    }
   
    
    public static void resultData( ArrayList<User> ls ) {
        // all items
        for( User item : ls ) {
            System.out.println(item.getUid() + " Name : " + item.getNameSurname());
        }
    } 
    
    
}
