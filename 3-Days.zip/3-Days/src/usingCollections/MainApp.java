
package usingCollections;

public class MainApp {
    
    public static void main(String[] args) {
        
        User us = new User();
        us.setAge(30);
        us.setMail("ali@ali.com");
        us.setNameSurname("ali bilmem");
        us.setUid(10);
        
        System.out.println( us.getMail() );
        
        
    }
    
}
