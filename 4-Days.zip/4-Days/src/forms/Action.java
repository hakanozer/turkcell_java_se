
package forms;

public class Action implements Runnable {

    String data = "";
    public Action(String data) {
        this.data = data;
    }
    

    @Override
    public void run() {
        
        boolean statu = false;
        int i = 1;
        for (;;) {
            i++;
            if (i == 10) {
                statu = true;
            }
            System.out.println("==== " + data);
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            if (statu)
            {
                break;
            }
        }
        
    }
    
    
    
}
