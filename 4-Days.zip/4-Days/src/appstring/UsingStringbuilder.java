
package appstring;


public class UsingStringbuilder {
    
    public static void main(String[] args) {
        
        long start = System.currentTimeMillis();
        String data = "";
        for (int i = 0; i < 10000; i++) {
            data += "Ali "+ i +System.lineSeparator();
        }
        //System.out.println(data);
        long end = System.currentTimeMillis();
        long between = end - start;
        
        
        
        
        // StringBuilder
        start = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            sb.append("Ali ").append(i).append(System.lineSeparator());
        }
        //System.out.println(sb.toString());
        end = System.currentTimeMillis();
        long betweenBuilder = end - start;
        
        System.out.println("+ time " + between);
        System.out.println("Stringbuilder time " + betweenBuilder);
        
        
    }
    
}
