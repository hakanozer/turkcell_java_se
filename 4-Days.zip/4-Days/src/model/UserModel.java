
package model;

import database.DB;
import database.Util;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserModel {
    
    
    DB db = new DB();
    public static int uid = 0;
    public static String name = "";
    
    
    public int userInsert( String name, String mail, String pass  ) {
        int rowCount = -1;
        
        try {
            String query = " insert into user values ( null, ? , ? , ? ) ";
            PreparedStatement pre = db.con(query);
            pre.setString(1, name);
            pre.setString(2, mail);
            pre.setString(3, Util.MD5(pass));
            rowCount = pre.executeUpdate();
            db.close();
        } catch (Exception e) {
            System.err.println("insert error : " + e);
        }
        
        return rowCount;
    }
    
    
    // user login control
    public boolean userLogin( String mail, String pass ) {
        boolean statu = false;
        try {
            String query = "select * from user where mail = ? and password = ?";
            PreparedStatement pre = db.con(query);
            pre.setString(1, mail);
            pre.setString(2, Util.MD5(pass));
            ResultSet rs = pre.executeQuery();
            statu = rs.next();
            uid = rs.getInt("uid");
            name = rs.getString("name");
            db.close();
        } catch (Exception e) {
            System.err.println("User Login Err : " + e);
        }
        return statu;
    }
    
    
}
