
package model;

import database.DB;
import database.Util;
import java.sql.PreparedStatement;

public class UserModel {
    
    
    DB db = new DB();
    
    
    public int userInsert( String name, String mail, String pass  ) {
        int rowCount = -1;
        
        try {
            String query = " insert into user values ( null, ? , ? , ? ) ";
            PreparedStatement pre = db.con(query);
            pre.setString(1, name);
            pre.setString(2, mail);
            pre.setString(3, Util.MD5(pass));
            rowCount = pre.executeUpdate();
            db.close();
        } catch (Exception e) {
            System.err.println("insert error : " + e);
        }
        
        return rowCount;
    }
    
    
}
