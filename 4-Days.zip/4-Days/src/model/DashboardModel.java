
package model;


import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import props.Currency;


public class DashboardModel {
    
    List<Currency> ls = new ArrayList<>();
    
    
    public void xmlRead() {
        ls.clear();
        try {
            String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
            String data = Jsoup.connect(url).timeout(30000).ignoreContentType(true).get().toString();
            Document doc =  Jsoup.parse(data, "", Parser.xmlParser());
            Elements elements = doc.getElementsByTag("Currency");
            for( Element item : elements ) {
                 String isim = item.getElementsByTag("Isim").text();
                 String ForexBuying = item.getElementsByTag("ForexBuying").text();
                 String ForexSelling = item.getElementsByTag("ForexSelling").text();
                 String BanknoteBuying = item.getElementsByTag("BanknoteBuying").text();
                 String BanknoteSelling = item.getElementsByTag("BanknoteSelling").text();
                 
                 Currency cr = new Currency(isim, ForexBuying, ForexSelling, BanknoteBuying, BanknoteSelling);
                 ls.add(cr);
                 
            }
            
        } catch (Exception e) {
            System.err.println("xml error : " + e);
        }
        
    }
    
    
    public DefaultTableModel tableResult() {
        DefaultTableModel dtm = new DefaultTableModel();
        
        dtm.addColumn("Isim");
        dtm.addColumn("ForexBuying");
        dtm.addColumn("ForexSelling");
        dtm.addColumn("BanknoteBuying");
        dtm.addColumn("BanknoteSelling");
        
        // row
        for(Currency item : ls) {
            String[] row = { item.getIsim(), item.getForexBuying(), item.getForexSelling(), item.getBanknoteBuying(), item.getBanknoteSelling() };
            dtm.addRow(row);
        }
        
        return dtm;
    }
    
    
}
