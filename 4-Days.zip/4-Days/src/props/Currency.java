
package props;

public class Currency {
    
    
    private String isim;
    private String ForexBuying;
    private String ForexSelling;
    private String BanknoteBuying;
    private String BanknoteSelling;

    public Currency( String isim, String ForexBuying, String ForexSelling, String BanknoteBuying, String BanknoteSelling) {
        this.isim = isim;
        this.ForexBuying = ForexBuying;
        this.ForexSelling = ForexSelling;
        this.BanknoteBuying = BanknoteBuying;
        this.BanknoteSelling = BanknoteSelling;
    }


    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getForexBuying() {
        return ForexBuying;
    }

    public void setForexBuying(String ForexBuying) {
        this.ForexBuying = ForexBuying;
    }

    public String getForexSelling() {
        return ForexSelling;
    }

    public void setForexSelling(String ForexSelling) {
        this.ForexSelling = ForexSelling;
    }

    public String getBanknoteBuying() {
        return BanknoteBuying;
    }

    public void setBanknoteBuying(String BanknoteBuying) {
        this.BanknoteBuying = BanknoteBuying;
    }

    public String getBanknoteSelling() {
        return BanknoteSelling;
    }

    public void setBanknoteSelling(String BanknoteSelling) {
        this.BanknoteSelling = BanknoteSelling;
    }
    
    
    
    
}
