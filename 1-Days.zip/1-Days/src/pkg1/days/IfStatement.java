package pkg1.days;

public class IfStatement {
    
    public static void main(String[] args) {
        
        int num1 = 10;
        int num2 = 11;
        
        if (num1 > 9) {
            System.out.println("Şart sağlandı");
        }else {
            System.out.println("Şart sağlanmadı");
        }
        
        
        // &&, ||
        // &&
        if (num1 > 9 && num2 < 20) {
            System.out.println("&& koşul sağlandı");
        }
        
        // ||
        if ( num1 > 11 || num2 > 10 ) {
            System.out.println("|| koşul sağlandı");
        }
        
        
        // && ||
        if ( (num1 > num2 || num1 > 9 && num2 > 11) || num2 > num1 ) {
            System.out.println("şart sağlandı");
        }else {
            System.out.println("Şart sağlanmadı");
        }
        
        
        String write = num1 > 5 ? "Ali" : "Veli";
        System.out.println("Write : " + write);
        
        
        
        String mail = "ali@ali.com";
        String pass = "";
        int age = 0;
        
        if ( mail.equals("") ) {
            System.out.println("Lütfen mail giriniz!");
        }else if ( pass.equals("") ) {
            System.out.println("Lütfen şifre giriniz!");
        }else if ( age == 0 ) {
            System.out.println("Lütfen yaşınızı giriniz!");
        }else {
            // hata yok, şartlar sağlandı
            // formu vt ye gönder
        }
        // ...
        
    }
    
}
