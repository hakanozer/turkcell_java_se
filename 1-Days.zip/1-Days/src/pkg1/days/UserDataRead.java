package pkg1.days;

import java.util.Scanner;

public class UserDataRead {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in);
        while (true) {
            System.out.println("Lütfen adınızı girini!");
            String name = read.nextLine();
            if (name.equals("")) {
                System.out.println("Adınız boş olamaz!");
            } else {
                if (name.equals("ali")) {
                    System.out.println(name + " Merhaba!");
                }
                System.out.println("Pull Data : " + name);
                break; // döngüyü kırar, Durdurur
            }
        }
        

    }

}
