
package pkg1.days;


public class TypeCasting {
    
    public static void main(String[] args) {
        
        // String to int
        String age = "    40   ";
        int convertAge = Integer.parseInt(age.trim());
        
        
        // String to double
        String num = "35.5";
        double convertNum = Double.parseDouble(num);
        double sm = convertNum + 1.7;
        System.out.println("Sm : " + sm);
        
        
        // double to int
        double d1 = 45.7; // 45
        double d2 = 45.8; // 45
        int cD1 = (int) (d1 + d2);
        System.out.println("cD1 : " + cD1);
        
        
        // char to int
        char c = '9';
        //int convertC = Integer.parseInt( String.valueOf(c) );
        int convertC = Integer.parseInt( c+"" );
        System.out.println("convertC : " + convertC);
 
        
    }
    
    
}
