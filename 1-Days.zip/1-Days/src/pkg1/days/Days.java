
package pkg1.days;


public class Days {

    
    public static void main(String[] args) {
        
        System.out.println("Hello World");
        
        // Variable
        // Türü DeğişkenAdı = DeğişkenDeğeri;
        // String
        String name = "";
        String number = "10";
        String nick = "10Numara";
        System.out.println("Nick : " + nick);
        
        // int
        int num1 = 30;
        int num2 = 40;
        int sum = num1 + num2;
        System.out.println("Sum : " + sum);
        
        
        // double
        double num3 = 40.5;
        System.out.println("Num3 : " + num3);
        
        
        // byte
        // 127 -128
        byte age = 127;
        
        
        //long
        long nlong = 5056756754563453756l;
        
        
        
        
        // boolean
        boolean statu = true;
        System.out.println("Statu : " + statu);
        
        
    }
    
    
    
    
    
}


