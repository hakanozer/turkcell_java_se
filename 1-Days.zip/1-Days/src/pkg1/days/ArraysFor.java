
package pkg1.days;



public class ArraysFor {
    
    public static void main(String[] args) {
        
        String[] userArr = new String[5];
        String[] userArr2 = { "Ali", "Veli", "Hasan", "Zehra", "Ayşe", "Mehmet" };
        Object[] userArr3 = { "Tatil", 40, true, 105.6 };
        

        // index using
        String var0 = userArr2[5];
        System.out.println("va0 " + var0);
        
        int size = userArr2.length;
        System.out.println("size : " + size);
        
        
        // all items
        for( int i = 0; i < size; i++ ) {
            System.out.println("i : " + userArr2[i] );
        }

        
        // foreach
        for ( String item : userArr2 ) {
            System.out.println("Foreach : " + item);
        }
            
            
        
        
    }
    
    
    
    
}
